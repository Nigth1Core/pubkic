---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
PC ^Z1DUHerd

DNS Request to:
*.home.clcreative.de ^sayhxdWY

Bind9
DNS Server ^wgODhWZG

DNS Request to:
* (websites) ^ntH7rfaa

DNS Lookup Chain ^tKVSkMSZ

Sophos XG
Firewall ^155lz70K

Cloudflare DNS ^sDtacgom

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 340,
			"versionNonce": 91429095,
			"isDeleted": false,
			"id": "ERBXz4caTOEcJ0EUsXbmF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -785.043212890625,
			"y": -212.27483384505564,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 123,
			"height": 154,
			"seed": 1097080391,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Z1DUHerd"
				},
				{
					"id": "1ntE-qJ_eTKbsMjKQE5Z5",
					"type": "arrow"
				},
				{
					"id": "5wL37t41t5D8cRTebjroh",
					"type": "arrow"
				},
				{
					"id": "SbGJ4CnWQFgWzq2i_9aXG",
					"type": "arrow"
				},
				{
					"id": "8CCl6YzE0L_3h9kBu3-UD",
					"type": "arrow"
				}
			],
			"updated": 1672654780939,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 293,
			"versionNonce": 1988899529,
			"isDeleted": false,
			"id": "Z1DUHerd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -737.043212890625,
			"y": -147.77483384505564,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27,
			"height": 25,
			"seed": 220794281,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654915514,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "PC",
			"rawText": "PC",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ERBXz4caTOEcJ0EUsXbmF",
			"originalText": "PC"
		},
		{
			"type": "text",
			"version": 210,
			"versionNonce": 1770873863,
			"isDeleted": false,
			"id": "sayhxdWY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -627.7728881835938,
			"y": -253.45420853987986,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 190,
			"height": 50,
			"seed": 220756103,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654780939,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS Request to:\n*.home.clcreative.de",
			"rawText": "DNS Request to:\n*.home.clcreative.de",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Request to:\n*.home.clcreative.de"
		},
		{
			"type": "rectangle",
			"version": 326,
			"versionNonce": 1265632233,
			"isDeleted": false,
			"id": "zm9Txn2E8D2acbtm1YsZH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -294.7958984375,
			"y": -215.10464494124705,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187,
			"height": 157,
			"seed": 303986537,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "wgODhWZG"
				},
				{
					"id": "1ntE-qJ_eTKbsMjKQE5Z5",
					"type": "arrow"
				},
				{
					"id": "5wL37t41t5D8cRTebjroh",
					"type": "arrow"
				},
				{
					"id": "DdjTQxawlknnN1mWZBCAW",
					"type": "arrow"
				},
				{
					"id": "SbGJ4CnWQFgWzq2i_9aXG",
					"type": "arrow"
				},
				{
					"id": "khDw2oK_bfAqyesb6L9DW",
					"type": "arrow"
				},
				{
					"id": "8CCl6YzE0L_3h9kBu3-UD",
					"type": "arrow"
				}
			],
			"updated": 1672654780939,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 486,
			"versionNonce": 1928699017,
			"isDeleted": false,
			"id": "wgODhWZG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -257.7958984375,
			"y": -161.60464494124705,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 113,
			"height": 50,
			"seed": 2125844391,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654891211,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Bind9\nDNS Server",
			"rawText": "Bind9\nDNS Server",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "zm9Txn2E8D2acbtm1YsZH",
			"originalText": "Bind9\nDNS Server"
		},
		{
			"type": "arrow",
			"version": 438,
			"versionNonce": 99414441,
			"isDeleted": false,
			"id": "1ntE-qJ_eTKbsMjKQE5Z5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -638.7272338867188,
			"y": -183.29188554183298,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 316.1058044433594,
			"height": 0,
			"seed": 1275961929,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915514,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ERBXz4caTOEcJ0EUsXbmF",
				"gap": 23.31597900390625,
				"focus": -0.6235980739841214
			},
			"endBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 27.825531005859375,
				"focus": 0.5947419184788018
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					316.1058044433594,
					0
				]
			]
		},
		{
			"type": "text",
			"version": 329,
			"versionNonce": 1025890633,
			"isDeleted": false,
			"id": "ntH7rfaa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -626.916276019225,
			"y": -48.14825880256308,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 168,
			"height": 50,
			"seed": 526481065,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654783596,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS Request to:\n* (websites)",
			"rawText": "DNS Request to:\n* (websites)",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Request to:\n* (websites)"
		},
		{
			"type": "arrow",
			"version": 505,
			"versionNonce": 747820169,
			"isDeleted": false,
			"id": "5wL37t41t5D8cRTebjroh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -638.0531412536,
			"y": -104.29395582404743,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 316.1058044433594,
			"height": 0,
			"seed": 445998183,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915514,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ERBXz4caTOEcJ0EUsXbmF",
				"gap": 23.99007163702504,
				"focus": 0.40234906520789887
			},
			"endBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 27.151438372740586,
				"focus": -0.4116011352509505
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					316.1058044433594,
					0
				]
			]
		},
		{
			"type": "text",
			"version": 127,
			"versionNonce": 448261479,
			"isDeleted": false,
			"id": "tKVSkMSZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -384.6967468261719,
			"y": -448.00533294677734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 567,
			"height": 82,
			"seed": 643768009,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654780939,
			"link": null,
			"locked": false,
			"fontSize": 64.54809570312501,
			"fontFamily": 1,
			"text": "DNS Lookup Chain",
			"rawText": "DNS Lookup Chain",
			"baseline": 57,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Lookup Chain"
		},
		{
			"type": "rectangle",
			"version": 495,
			"versionNonce": 2132099209,
			"isDeleted": false,
			"id": "QEBkhANn1Lfk1YaE7dg-o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 59.415374755859375,
			"y": -217.93091583251953,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187,
			"height": 157,
			"seed": 1524197129,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "155lz70K"
				},
				{
					"id": "QwJ32wHYw96lbe199nPFN",
					"type": "arrow"
				},
				{
					"id": "DdjTQxawlknnN1mWZBCAW",
					"type": "arrow"
				},
				{
					"id": "yWR_VQRG65PrM-cVSoBHi",
					"type": "arrow"
				},
				{
					"id": "khDw2oK_bfAqyesb6L9DW",
					"type": "arrow"
				}
			],
			"updated": 1672654780939,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 701,
			"versionNonce": 939326151,
			"isDeleted": false,
			"id": "155lz70K",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 100.91537475585938,
			"y": -164.43091583251953,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 50,
			"seed": 1729833479,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654898311,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sophos XG\nFirewall",
			"rawText": "Sophos XG\nFirewall",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "QEBkhANn1Lfk1YaE7dg-o",
			"originalText": "Sophos XG\nFirewall"
		},
		{
			"type": "freedraw",
			"version": 329,
			"versionNonce": 1032734569,
			"isDeleted": false,
			"id": "xAs_MszagCUWe1ynkqJuv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 439.6258239746094,
			"y": -92.29702301025384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 251.0394287109375,
			"height": 121.41180419921875,
			"seed": 1471695305,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654780939,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.82568359375,
					0
				],
				[
					-2.738525390625,
					0
				],
				[
					-4.5643310546875,
					0
				],
				[
					-4.5643310546875,
					-0.912841796875
				],
				[
					-8.2158203125,
					-3.6514892578125
				],
				[
					-10.04150390625,
					-6.39007568359375
				],
				[
					-11.8673095703125,
					-10.04156494140625
				],
				[
					-12.7801513671875,
					-11.8673095703125
				],
				[
					-14.60595703125,
					-16.431640625
				],
				[
					-14.60595703125,
					-19.170257568359375
				],
				[
					-15.518798828125,
					-23.734619140625
				],
				[
					-14.60595703125,
					-28.298980712890625
				],
				[
					-13.6929931640625,
					-31.950469970703125
				],
				[
					-11.8673095703125,
					-34.689056396484375
				],
				[
					-10.9544677734375,
					-36.514801025390625
				],
				[
					-10.04150390625,
					-36.514801025390625
				],
				[
					-7.302978515625,
					-36.514801025390625
				],
				[
					-3.6514892578125,
					-36.514801025390625
				],
				[
					1.8258056640625,
					-36.514801025390625
				],
				[
					6.39013671875,
					-36.514801025390625
				],
				[
					9.1287841796875,
					-36.514801025390625
				],
				[
					10.0416259765625,
					-36.514801025390625
				],
				[
					11.8673095703125,
					-36.514801025390625
				],
				[
					15.518798828125,
					-35.6019287109375
				],
				[
					18.2574462890625,
					-33.77618408203125
				],
				[
					20.0831298828125,
					-33.77618408203125
				],
				[
					20.0831298828125,
					-32.86334228515625
				],
				[
					20.0831298828125,
					-31.950469970703125
				],
				[
					20.99609375,
					-31.03759765625
				],
				[
					20.0831298828125,
					-31.03759765625
				],
				[
					19.1702880859375,
					-31.03759765625
				],
				[
					19.1702880859375,
					-31.950469970703125
				],
				[
					19.1702880859375,
					-32.86334228515625
				],
				[
					19.1702880859375,
					-33.77618408203125
				],
				[
					19.1702880859375,
					-37.42767333984375
				],
				[
					19.1702880859375,
					-41.992034912109375
				],
				[
					19.1702880859375,
					-44.73065185546875
				],
				[
					19.1702880859375,
					-48.38214111328125
				],
				[
					19.1702880859375,
					-52.03363037109375
				],
				[
					21.908935546875,
					-59.336578369140625
				],
				[
					25.5604248046875,
					-66.63955688476562
				],
				[
					29.2119140625,
					-73.02963256835938
				],
				[
					31.9505615234375,
					-75.76824951171875
				],
				[
					32.8634033203125,
					-77.593994140625
				],
				[
					34.6890869140625,
					-79.41973876953125
				],
				[
					36.514892578125,
					-81.2454833984375
				],
				[
					38.340576171875,
					-83.07122802734375
				],
				[
					39.25341796875,
					-84.89697265625
				],
				[
					40.1663818359375,
					-84.89697265625
				],
				[
					41.9920654296875,
					-84.89697265625
				],
				[
					42.9049072265625,
					-84.89697265625
				],
				[
					46.556396484375,
					-84.89697265625
				],
				[
					50.2078857421875,
					-83.07122802734375
				],
				[
					52.946533203125,
					-81.2454833984375
				],
				[
					57.5108642578125,
					-76.68112182617188
				],
				[
					59.336669921875,
					-73.02963256835938
				],
				[
					60.24951171875,
					-70.29104614257812
				],
				[
					62.0751953125,
					-67.55242919921875
				],
				[
					62.9881591796875,
					-63.90093994140625
				],
				[
					64.8138427734375,
					-60.24945068359375
				],
				[
					65.7266845703125,
					-56.59796142578125
				],
				[
					66.6396484375,
					-55.685089111328125
				],
				[
					66.6396484375,
					-54.772216796875
				],
				[
					67.552490234375,
					-54.772216796875
				],
				[
					67.552490234375,
					-56.59796142578125
				],
				[
					71.2039794921875,
					-62.988067626953125
				],
				[
					74.85546875,
					-70.29104614257812
				],
				[
					79.4197998046875,
					-76.68112182617188
				],
				[
					82.158447265625,
					-82.15835571289062
				],
				[
					83.984130859375,
					-85.80984497070312
				],
				[
					85.8099365234375,
					-88.5484619140625
				],
				[
					90.374267578125,
					-91.28704833984375
				],
				[
					94.0257568359375,
					-93.11279296875
				],
				[
					96.764404296875,
					-94.02566528320312
				],
				[
					100.415771484375,
					-95.85140991210938
				],
				[
					104.0672607421875,
					-97.67715454101562
				],
				[
					108.6317138671875,
					-100.415771484375
				],
				[
					111.3702392578125,
					-102.24151611328125
				],
				[
					115.9346923828125,
					-104.0672607421875
				],
				[
					120.4989013671875,
					-107.71875
				],
				[
					128.7147216796875,
					-110.45736694335938
				],
				[
					136.9305419921875,
					-113.19595336914062
				],
				[
					142.4078369140625,
					-114.10882568359375
				],
				[
					146.0594482421875,
					-114.10882568359375
				],
				[
					148.7979736328125,
					-114.10882568359375
				],
				[
					149.7108154296875,
					-114.10882568359375
				],
				[
					152.4495849609375,
					-112.2830810546875
				],
				[
					154.2752685546875,
					-110.45736694335938
				],
				[
					156.1009521484375,
					-107.71875
				],
				[
					158.8394775390625,
					-103.15438842773438
				],
				[
					160.6654052734375,
					-99.50289916992188
				],
				[
					162.4910888671875,
					-96.7642822265625
				],
				[
					164.3167724609375,
					-93.11279296875
				],
				[
					164.3167724609375,
					-91.28704833984375
				],
				[
					164.3167724609375,
					-87.63558959960938
				],
				[
					164.3167724609375,
					-83.98410034179688
				],
				[
					163.4039306640625,
					-76.68112182617188
				],
				[
					161.5782470703125,
					-73.02963256835938
				],
				[
					159.7523193359375,
					-66.63955688476562
				],
				[
					157.0137939453125,
					-61.162322998046875
				],
				[
					156.1009521484375,
					-59.336578369140625
				],
				[
					155.1881103515625,
					-56.59796142578125
				],
				[
					155.1881103515625,
					-55.685089111328125
				],
				[
					154.2752685546875,
					-55.685089111328125
				],
				[
					152.4495849609375,
					-55.685089111328125
				],
				[
					151.5364990234375,
					-54.772216796875
				],
				[
					151.5364990234375,
					-55.685089111328125
				],
				[
					152.4495849609375,
					-57.510833740234375
				],
				[
					156.1009521484375,
					-59.336578369140625
				],
				[
					160.6654052734375,
					-62.988067626953125
				],
				[
					164.3167724609375,
					-64.81381225585938
				],
				[
					167.9683837890625,
					-65.7266845703125
				],
				[
					170.7069091796875,
					-66.63955688476562
				],
				[
					172.5325927734375,
					-66.63955688476562
				],
				[
					174.3582763671875,
					-66.63955688476562
				],
				[
					176.1842041015625,
					-66.63955688476562
				],
				[
					180.7484130859375,
					-66.63955688476562
				],
				[
					184.4000244140625,
					-65.7266845703125
				],
				[
					188.9642333984375,
					-65.7266845703125
				],
				[
					192.6158447265625,
					-65.7266845703125
				],
				[
					193.5286865234375,
					-65.7266845703125
				],
				[
					195.3543701171875,
					-65.7266845703125
				],
				[
					199.0059814453125,
					-64.81381225585938
				],
				[
					202.6573486328125,
					-61.162322998046875
				],
				[
					207.2218017578125,
					-57.510833740234375
				],
				[
					209.0474853515625,
					-54.772216796875
				],
				[
					210.8731689453125,
					-51.120758056640625
				],
				[
					212.6988525390625,
					-48.38214111328125
				],
				[
					212.6988525390625,
					-44.73065185546875
				],
				[
					213.6119384765625,
					-40.166290283203125
				],
				[
					213.6119384765625,
					-36.514801025390625
				],
				[
					213.6119384765625,
					-33.77618408203125
				],
				[
					213.6119384765625,
					-30.124725341796875
				],
				[
					213.6119384765625,
					-28.298980712890625
				],
				[
					212.6988525390625,
					-27.3861083984375
				],
				[
					211.7860107421875,
					-25.56036376953125
				],
				[
					210.8731689453125,
					-24.647491455078125
				],
				[
					211.7860107421875,
					-24.647491455078125
				],
				[
					213.6119384765625,
					-25.56036376953125
				],
				[
					217.2633056640625,
					-26.473236083984375
				],
				[
					219.0889892578125,
					-26.473236083984375
				],
				[
					228.2176513671875,
					-26.473236083984375
				],
				[
					232.7821044921875,
					-24.647491455078125
				],
				[
					235.5206298828125,
					-23.734619140625
				],
				[
					235.5206298828125,
					-22.821746826171875
				],
				[
					235.5206298828125,
					-20.0831298828125
				],
				[
					235.5206298828125,
					-17.34454345703125
				],
				[
					234.6077880859375,
					-14.60589599609375
				],
				[
					234.6077880859375,
					-12.7801513671875
				],
				[
					231.8692626953125,
					-9.128662109375
				],
				[
					230.0435791015625,
					-7.30291748046875
				],
				[
					229.1307373046875,
					-4.5643310546875
				],
				[
					226.3919677734375,
					-1.82574462890625
				],
				[
					223.6534423828125,
					-1.82574462890625
				],
				[
					220.0018310546875,
					0
				],
				[
					215.4376220703125,
					0.91290283203125
				],
				[
					210.8731689453125,
					2.7386474609375
				],
				[
					206.3089599609375,
					3.6514892578125
				],
				[
					199.0059814453125,
					3.6514892578125
				],
				[
					194.4415283203125,
					3.6514892578125
				],
				[
					189.8770751953125,
					3.6514892578125
				],
				[
					183.4871826171875,
					3.6514892578125
				],
				[
					176.1842041015625,
					3.6514892578125
				],
				[
					166.1424560546875,
					3.6514892578125
				],
				[
					157.9266357421875,
					3.6514892578125
				],
				[
					147.8851318359375,
					3.6514892578125
				],
				[
					135.1048583984375,
					5.47723388671875
				],
				[
					125.9761962890625,
					5.47723388671875
				],
				[
					116.8475341796875,
					5.47723388671875
				],
				[
					104.980224609375,
					5.47723388671875
				],
				[
					95.8514404296875,
					5.47723388671875
				],
				[
					86.7227783203125,
					5.47723388671875
				],
				[
					77.5941162109375,
					6.39013671875
				],
				[
					70.2911376953125,
					7.302978515625
				],
				[
					62.9881591796875,
					7.302978515625
				],
				[
					57.5108642578125,
					7.302978515625
				],
				[
					52.946533203125,
					7.302978515625
				],
				[
					47.4693603515625,
					7.302978515625
				],
				[
					42.9049072265625,
					7.302978515625
				],
				[
					39.25341796875,
					7.302978515625
				],
				[
					34.6890869140625,
					7.302978515625
				],
				[
					31.03759765625,
					7.302978515625
				],
				[
					28.299072265625,
					6.39013671875
				],
				[
					26.4732666015625,
					6.39013671875
				],
				[
					23.734619140625,
					5.47723388671875
				],
				[
					20.99609375,
					5.47723388671875
				],
				[
					16.4317626953125,
					4.56439208984375
				],
				[
					13.693115234375,
					4.56439208984375
				],
				[
					12.7802734375,
					4.56439208984375
				],
				[
					10.9544677734375,
					4.56439208984375
				],
				[
					10.0416259765625,
					4.56439208984375
				],
				[
					8.2158203125,
					3.6514892578125
				],
				[
					7.302978515625,
					2.7386474609375
				],
				[
					6.39013671875,
					2.7386474609375
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "text",
			"version": 193,
			"versionNonce": 259200105,
			"isDeleted": false,
			"id": "sDtacgom",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 480.7050476074219,
			"y": -134.16033477783196,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 152,
			"height": 25,
			"seed": 1784555113,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654913984,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Cloudflare DNS",
			"rawText": "Cloudflare DNS",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cloudflare DNS"
		},
		{
			"type": "arrow",
			"version": 774,
			"versionNonce": 2003869735,
			"isDeleted": false,
			"id": "DdjTQxawlknnN1mWZBCAW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -99.24371949390985,
			"y": -140.55403044140013,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 151.81229249195673,
			"height": 0,
			"seed": 1733331465,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915515,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 8.55217894359015,
				"focus": -0.05031064331405203
			},
			"endBinding": {
				"elementId": "QEBkhANn1Lfk1YaE7dg-o",
				"gap": 6.8468017578125,
				"focus": 0.014307192469816545
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					151.81229249195673,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 809,
			"versionNonce": 1261176393,
			"isDeleted": false,
			"id": "SbGJ4CnWQFgWzq2i_9aXG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -325.46056213378904,
			"y": -157.35132250087293,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 312.5669921875001,
			"height": 0,
			"seed": 2004095529,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915514,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 30.66466369628904,
				"focus": 0.2642888861098838
			},
			"endBinding": {
				"elementId": "ERBXz4caTOEcJ0EUsXbmF",
				"gap": 24.01565856933587,
				"focus": -0.2867076448807439
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-312.5669921875001,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 743,
			"versionNonce": 353589511,
			"isDeleted": false,
			"id": "QwJ32wHYw96lbe199nPFN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 261.30699522658006,
			"y": -136.77712325183734,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 151.81229249195673,
			"height": 0,
			"seed": 1999388903,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915515,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QEBkhANn1Lfk1YaE7dg-o",
				"gap": 14.891620470720682,
				"focus": 0.033806274913148956
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					151.81229249195673,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 34,
			"versionNonce": 1837504969,
			"isDeleted": false,
			"id": "yWR_VQRG65PrM-cVSoBHi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 415.06028747558594,
			"y": -104.31850119693581,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 150.44111328124995,
			"height": 0,
			"seed": 74581703,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915515,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "QEBkhANn1Lfk1YaE7dg-o",
				"gap": 18.203799438476608,
				"focus": 0.44729190618577996
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-150.44111328124995,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 47,
			"versionNonce": 1930557609,
			"isDeleted": false,
			"id": "khDw2oK_bfAqyesb6L9DW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 52.102865600585886,
			"y": -108.70028830631075,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 144.59873046874995,
			"height": 1.4210854715202004e-14,
			"seed": 454852969,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915515,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QEBkhANn1Lfk1YaE7dg-o",
				"gap": 7.31250915527346,
				"focus": -0.3914729621173091
			},
			"endBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 15.300033569335938,
				"focus": 0.3554695112730736
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-144.59873046874995,
					-1.4210854715202004e-14
				]
			]
		},
		{
			"type": "arrow",
			"version": 78,
			"versionNonce": 452184073,
			"isDeleted": false,
			"id": "8CCl6YzE0L_3h9kBu3-UD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -317.42726135253906,
			"y": -72.91571799381074,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 322.791162109375,
			"height": 0,
			"seed": 768124329,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654915514,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 22.631362915039062,
				"focus": -0.8113239101584242
			},
			"endBinding": {
				"elementId": "ERBXz4caTOEcJ0EUsXbmF",
				"gap": 21.824789428710915,
				"focus": 0.809858647418765
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-322.791162109375,
					0
				]
			]
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#862e9c",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 851.3312408447266,
		"scrollY": 691.2654677496703,
		"zoom": {
			"value": 1.25
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%