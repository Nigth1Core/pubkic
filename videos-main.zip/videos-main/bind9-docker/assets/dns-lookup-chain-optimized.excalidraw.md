---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Bind9
DNS Server ^wgODhWZG

DNS Lookup Chain (optimized) ^tKVSkMSZ

Cloudflare DNS ^sDtacgom

PC ^8tsoekoB

DNS Request to:
*.home.clcreative.de ^T6N50CbB

Sophos XG
Firewall ^O03O86vz

DNS Request to:
* (websites) ^vgVUWYei

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 478,
			"versionNonce": 1645201001,
			"isDeleted": false,
			"id": "zm9Txn2E8D2acbtm1YsZH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -312.32304687499993,
			"y": 88.69869978531557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187,
			"height": 157,
			"seed": 303986537,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "wgODhWZG"
				},
				{
					"id": "QwJ32wHYw96lbe199nPFN",
					"type": "arrow"
				},
				{
					"id": "v36zKd-MLys2jqjI1FxgJ",
					"type": "arrow"
				}
			],
			"updated": 1672654833660,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 639,
			"versionNonce": 1187773769,
			"isDeleted": false,
			"id": "wgODhWZG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -275.32304687499993,
			"y": 142.19869978531557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 113,
			"height": 50,
			"seed": 2125844391,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654881233,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Bind9\nDNS Server",
			"rawText": "Bind9\nDNS Server",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "zm9Txn2E8D2acbtm1YsZH",
			"originalText": "Bind9\nDNS Server"
		},
		{
			"type": "text",
			"version": 196,
			"versionNonce": 1411917609,
			"isDeleted": false,
			"id": "tKVSkMSZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -697.7948869185016,
			"y": -422.27895910089666,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 931,
			"height": 82,
			"seed": 643768009,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672651739116,
			"link": null,
			"locked": false,
			"fontSize": 64.54809570312501,
			"fontFamily": 1,
			"text": "DNS Lookup Chain (optimized)",
			"rawText": "DNS Lookup Chain (optimized)",
			"baseline": 57,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Lookup Chain (optimized)"
		},
		{
			"type": "freedraw",
			"version": 339,
			"versionNonce": 1350073769,
			"isDeleted": false,
			"id": "xAs_MszagCUWe1ynkqJuv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 143.85560913085942,
			"y": -89.3758316040039,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 251.0394287109375,
			"height": 121.41180419921875,
			"seed": 1471695305,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672651716811,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.82568359375,
					0
				],
				[
					-2.738525390625,
					0
				],
				[
					-4.5643310546875,
					0
				],
				[
					-4.5643310546875,
					-0.912841796875
				],
				[
					-8.2158203125,
					-3.6514892578125
				],
				[
					-10.04150390625,
					-6.39007568359375
				],
				[
					-11.8673095703125,
					-10.04156494140625
				],
				[
					-12.7801513671875,
					-11.8673095703125
				],
				[
					-14.60595703125,
					-16.431640625
				],
				[
					-14.60595703125,
					-19.170257568359375
				],
				[
					-15.518798828125,
					-23.734619140625
				],
				[
					-14.60595703125,
					-28.298980712890625
				],
				[
					-13.6929931640625,
					-31.950469970703125
				],
				[
					-11.8673095703125,
					-34.689056396484375
				],
				[
					-10.9544677734375,
					-36.514801025390625
				],
				[
					-10.04150390625,
					-36.514801025390625
				],
				[
					-7.302978515625,
					-36.514801025390625
				],
				[
					-3.6514892578125,
					-36.514801025390625
				],
				[
					1.8258056640625,
					-36.514801025390625
				],
				[
					6.39013671875,
					-36.514801025390625
				],
				[
					9.1287841796875,
					-36.514801025390625
				],
				[
					10.0416259765625,
					-36.514801025390625
				],
				[
					11.8673095703125,
					-36.514801025390625
				],
				[
					15.518798828125,
					-35.6019287109375
				],
				[
					18.2574462890625,
					-33.77618408203125
				],
				[
					20.0831298828125,
					-33.77618408203125
				],
				[
					20.0831298828125,
					-32.86334228515625
				],
				[
					20.0831298828125,
					-31.950469970703125
				],
				[
					20.99609375,
					-31.03759765625
				],
				[
					20.0831298828125,
					-31.03759765625
				],
				[
					19.1702880859375,
					-31.03759765625
				],
				[
					19.1702880859375,
					-31.950469970703125
				],
				[
					19.1702880859375,
					-32.86334228515625
				],
				[
					19.1702880859375,
					-33.77618408203125
				],
				[
					19.1702880859375,
					-37.42767333984375
				],
				[
					19.1702880859375,
					-41.992034912109375
				],
				[
					19.1702880859375,
					-44.73065185546875
				],
				[
					19.1702880859375,
					-48.38214111328125
				],
				[
					19.1702880859375,
					-52.03363037109375
				],
				[
					21.908935546875,
					-59.336578369140625
				],
				[
					25.5604248046875,
					-66.63955688476562
				],
				[
					29.2119140625,
					-73.02963256835938
				],
				[
					31.9505615234375,
					-75.76824951171875
				],
				[
					32.8634033203125,
					-77.593994140625
				],
				[
					34.6890869140625,
					-79.41973876953125
				],
				[
					36.514892578125,
					-81.2454833984375
				],
				[
					38.340576171875,
					-83.07122802734375
				],
				[
					39.25341796875,
					-84.89697265625
				],
				[
					40.1663818359375,
					-84.89697265625
				],
				[
					41.9920654296875,
					-84.89697265625
				],
				[
					42.9049072265625,
					-84.89697265625
				],
				[
					46.556396484375,
					-84.89697265625
				],
				[
					50.2078857421875,
					-83.07122802734375
				],
				[
					52.946533203125,
					-81.2454833984375
				],
				[
					57.5108642578125,
					-76.68112182617188
				],
				[
					59.336669921875,
					-73.02963256835938
				],
				[
					60.24951171875,
					-70.29104614257812
				],
				[
					62.0751953125,
					-67.55242919921875
				],
				[
					62.9881591796875,
					-63.90093994140625
				],
				[
					64.8138427734375,
					-60.24945068359375
				],
				[
					65.7266845703125,
					-56.59796142578125
				],
				[
					66.6396484375,
					-55.685089111328125
				],
				[
					66.6396484375,
					-54.772216796875
				],
				[
					67.552490234375,
					-54.772216796875
				],
				[
					67.552490234375,
					-56.59796142578125
				],
				[
					71.2039794921875,
					-62.988067626953125
				],
				[
					74.85546875,
					-70.29104614257812
				],
				[
					79.4197998046875,
					-76.68112182617188
				],
				[
					82.158447265625,
					-82.15835571289062
				],
				[
					83.984130859375,
					-85.80984497070312
				],
				[
					85.8099365234375,
					-88.5484619140625
				],
				[
					90.374267578125,
					-91.28704833984375
				],
				[
					94.0257568359375,
					-93.11279296875
				],
				[
					96.764404296875,
					-94.02566528320312
				],
				[
					100.415771484375,
					-95.85140991210938
				],
				[
					104.0672607421875,
					-97.67715454101562
				],
				[
					108.6317138671875,
					-100.415771484375
				],
				[
					111.3702392578125,
					-102.24151611328125
				],
				[
					115.9346923828125,
					-104.0672607421875
				],
				[
					120.4989013671875,
					-107.71875
				],
				[
					128.7147216796875,
					-110.45736694335938
				],
				[
					136.9305419921875,
					-113.19595336914062
				],
				[
					142.4078369140625,
					-114.10882568359375
				],
				[
					146.0594482421875,
					-114.10882568359375
				],
				[
					148.7979736328125,
					-114.10882568359375
				],
				[
					149.7108154296875,
					-114.10882568359375
				],
				[
					152.4495849609375,
					-112.2830810546875
				],
				[
					154.2752685546875,
					-110.45736694335938
				],
				[
					156.1009521484375,
					-107.71875
				],
				[
					158.8394775390625,
					-103.15438842773438
				],
				[
					160.6654052734375,
					-99.50289916992188
				],
				[
					162.4910888671875,
					-96.7642822265625
				],
				[
					164.3167724609375,
					-93.11279296875
				],
				[
					164.3167724609375,
					-91.28704833984375
				],
				[
					164.3167724609375,
					-87.63558959960938
				],
				[
					164.3167724609375,
					-83.98410034179688
				],
				[
					163.4039306640625,
					-76.68112182617188
				],
				[
					161.5782470703125,
					-73.02963256835938
				],
				[
					159.7523193359375,
					-66.63955688476562
				],
				[
					157.0137939453125,
					-61.162322998046875
				],
				[
					156.1009521484375,
					-59.336578369140625
				],
				[
					155.1881103515625,
					-56.59796142578125
				],
				[
					155.1881103515625,
					-55.685089111328125
				],
				[
					154.2752685546875,
					-55.685089111328125
				],
				[
					152.4495849609375,
					-55.685089111328125
				],
				[
					151.5364990234375,
					-54.772216796875
				],
				[
					151.5364990234375,
					-55.685089111328125
				],
				[
					152.4495849609375,
					-57.510833740234375
				],
				[
					156.1009521484375,
					-59.336578369140625
				],
				[
					160.6654052734375,
					-62.988067626953125
				],
				[
					164.3167724609375,
					-64.81381225585938
				],
				[
					167.9683837890625,
					-65.7266845703125
				],
				[
					170.7069091796875,
					-66.63955688476562
				],
				[
					172.5325927734375,
					-66.63955688476562
				],
				[
					174.3582763671875,
					-66.63955688476562
				],
				[
					176.1842041015625,
					-66.63955688476562
				],
				[
					180.7484130859375,
					-66.63955688476562
				],
				[
					184.4000244140625,
					-65.7266845703125
				],
				[
					188.9642333984375,
					-65.7266845703125
				],
				[
					192.6158447265625,
					-65.7266845703125
				],
				[
					193.5286865234375,
					-65.7266845703125
				],
				[
					195.3543701171875,
					-65.7266845703125
				],
				[
					199.0059814453125,
					-64.81381225585938
				],
				[
					202.6573486328125,
					-61.162322998046875
				],
				[
					207.2218017578125,
					-57.510833740234375
				],
				[
					209.0474853515625,
					-54.772216796875
				],
				[
					210.8731689453125,
					-51.120758056640625
				],
				[
					212.6988525390625,
					-48.38214111328125
				],
				[
					212.6988525390625,
					-44.73065185546875
				],
				[
					213.6119384765625,
					-40.166290283203125
				],
				[
					213.6119384765625,
					-36.514801025390625
				],
				[
					213.6119384765625,
					-33.77618408203125
				],
				[
					213.6119384765625,
					-30.124725341796875
				],
				[
					213.6119384765625,
					-28.298980712890625
				],
				[
					212.6988525390625,
					-27.3861083984375
				],
				[
					211.7860107421875,
					-25.56036376953125
				],
				[
					210.8731689453125,
					-24.647491455078125
				],
				[
					211.7860107421875,
					-24.647491455078125
				],
				[
					213.6119384765625,
					-25.56036376953125
				],
				[
					217.2633056640625,
					-26.473236083984375
				],
				[
					219.0889892578125,
					-26.473236083984375
				],
				[
					228.2176513671875,
					-26.473236083984375
				],
				[
					232.7821044921875,
					-24.647491455078125
				],
				[
					235.5206298828125,
					-23.734619140625
				],
				[
					235.5206298828125,
					-22.821746826171875
				],
				[
					235.5206298828125,
					-20.0831298828125
				],
				[
					235.5206298828125,
					-17.34454345703125
				],
				[
					234.6077880859375,
					-14.60589599609375
				],
				[
					234.6077880859375,
					-12.7801513671875
				],
				[
					231.8692626953125,
					-9.128662109375
				],
				[
					230.0435791015625,
					-7.30291748046875
				],
				[
					229.1307373046875,
					-4.5643310546875
				],
				[
					226.3919677734375,
					-1.82574462890625
				],
				[
					223.6534423828125,
					-1.82574462890625
				],
				[
					220.0018310546875,
					0
				],
				[
					215.4376220703125,
					0.91290283203125
				],
				[
					210.8731689453125,
					2.7386474609375
				],
				[
					206.3089599609375,
					3.6514892578125
				],
				[
					199.0059814453125,
					3.6514892578125
				],
				[
					194.4415283203125,
					3.6514892578125
				],
				[
					189.8770751953125,
					3.6514892578125
				],
				[
					183.4871826171875,
					3.6514892578125
				],
				[
					176.1842041015625,
					3.6514892578125
				],
				[
					166.1424560546875,
					3.6514892578125
				],
				[
					157.9266357421875,
					3.6514892578125
				],
				[
					147.8851318359375,
					3.6514892578125
				],
				[
					135.1048583984375,
					5.47723388671875
				],
				[
					125.9761962890625,
					5.47723388671875
				],
				[
					116.8475341796875,
					5.47723388671875
				],
				[
					104.980224609375,
					5.47723388671875
				],
				[
					95.8514404296875,
					5.47723388671875
				],
				[
					86.7227783203125,
					5.47723388671875
				],
				[
					77.5941162109375,
					6.39013671875
				],
				[
					70.2911376953125,
					7.302978515625
				],
				[
					62.9881591796875,
					7.302978515625
				],
				[
					57.5108642578125,
					7.302978515625
				],
				[
					52.946533203125,
					7.302978515625
				],
				[
					47.4693603515625,
					7.302978515625
				],
				[
					42.9049072265625,
					7.302978515625
				],
				[
					39.25341796875,
					7.302978515625
				],
				[
					34.6890869140625,
					7.302978515625
				],
				[
					31.03759765625,
					7.302978515625
				],
				[
					28.299072265625,
					6.39013671875
				],
				[
					26.4732666015625,
					6.39013671875
				],
				[
					23.734619140625,
					5.47723388671875
				],
				[
					20.99609375,
					5.47723388671875
				],
				[
					16.4317626953125,
					4.56439208984375
				],
				[
					13.693115234375,
					4.56439208984375
				],
				[
					12.7802734375,
					4.56439208984375
				],
				[
					10.9544677734375,
					4.56439208984375
				],
				[
					10.0416259765625,
					4.56439208984375
				],
				[
					8.2158203125,
					3.6514892578125
				],
				[
					7.302978515625,
					2.7386474609375
				],
				[
					6.39013671875,
					2.7386474609375
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "text",
			"version": 203,
			"versionNonce": 1819011303,
			"isDeleted": false,
			"id": "sDtacgom",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 184.93483276367192,
			"y": -131.23914337158203,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 152,
			"height": 25,
			"seed": 1784555113,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654918946,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Cloudflare DNS",
			"rawText": "Cloudflare DNS",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cloudflare DNS"
		},
		{
			"type": "arrow",
			"version": 931,
			"versionNonce": 280693831,
			"isDeleted": false,
			"id": "QwJ32wHYw96lbe199nPFN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -217.63256277097096,
			"y": -47.423384009435864,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 0.30949547171579184,
			"height": 130.46549903884846,
			"seed": 1999388903,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 21.15731760105851,
				"focus": -0.11366156679205804
			},
			"endBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 5.656584755902941,
				"focus": 0.018141613299859725
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.30949547171579184,
					130.46549903884846
				]
			]
		},
		{
			"type": "arrow",
			"version": 51,
			"versionNonce": 1648356199,
			"isDeleted": false,
			"id": "v36zKd-MLys2jqjI1FxgJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -247.57219924926756,
			"y": 81.21500397105466,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 2.2821807861328125,
			"height": 130.084114074707,
			"seed": 410776105,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zm9Txn2E8D2acbtm1YsZH",
				"gap": 7.483695814260898,
				"focus": -0.28711498343178515
			},
			"endBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 19.711591506842012,
				"focus": 0.24304993890427865
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-2.2821807861328125,
					-130.084114074707
				]
			]
		},
		{
			"type": "rectangle",
			"version": 390,
			"versionNonce": 1372993543,
			"isDeleted": false,
			"id": "3TtpjyrQVmQkhn_rBffX_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -812.2648109436036,
			"y": -222.75089051430297,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 123,
			"height": 154,
			"seed": 1514711559,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "8tsoekoB"
				},
				{
					"id": "9jHUT0Rt0VQplyRicavev",
					"type": "arrow"
				},
				{
					"id": "V0RAsl1KorW0Mt2wD8KqL",
					"type": "arrow"
				},
				{
					"id": "Xp-J3SmXVq-zbqzMIKE8f",
					"type": "arrow"
				},
				{
					"id": "WCzEoPIjXOvYruQjC6y4w",
					"type": "arrow"
				}
			],
			"updated": 1672654858342,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 339,
			"versionNonce": 1497418023,
			"isDeleted": false,
			"id": "8tsoekoB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -764.2648109436036,
			"y": -158.25089051430297,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27,
			"height": 25,
			"seed": 1265901033,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "PC",
			"rawText": "PC",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "3TtpjyrQVmQkhn_rBffX_",
			"originalText": "PC"
		},
		{
			"type": "text",
			"version": 254,
			"versionNonce": 1262566313,
			"isDeleted": false,
			"id": "T6N50CbB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -654.9944862365724,
			"y": -263.9302652091272,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 190,
			"height": 50,
			"seed": 1809043751,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654855596,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS Request to:\n*.home.clcreative.de",
			"rawText": "DNS Request to:\n*.home.clcreative.de",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Request to:\n*.home.clcreative.de"
		},
		{
			"type": "rectangle",
			"version": 380,
			"versionNonce": 1493260937,
			"isDeleted": false,
			"id": "30k8vHR0qaCAN7itFEfmh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -322.0174964904786,
			"y": -225.58070161049437,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187,
			"height": 157,
			"seed": 1223325897,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "O03O86vz"
				},
				{
					"id": "QwJ32wHYw96lbe199nPFN",
					"type": "arrow"
				},
				{
					"id": "v36zKd-MLys2jqjI1FxgJ",
					"type": "arrow"
				},
				{
					"id": "9jHUT0Rt0VQplyRicavev",
					"type": "arrow"
				},
				{
					"id": "V0RAsl1KorW0Mt2wD8KqL",
					"type": "arrow"
				},
				{
					"id": "Xp-J3SmXVq-zbqzMIKE8f",
					"type": "arrow"
				},
				{
					"id": "WCzEoPIjXOvYruQjC6y4w",
					"type": "arrow"
				},
				{
					"id": "kDzzTkz5wGQZ9uJdTD9fG",
					"type": "arrow"
				},
				{
					"id": "TNdZarb9TRJmRWdG-UZ8r",
					"type": "arrow"
				}
			],
			"updated": 1672654936638,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 564,
			"versionNonce": 2049431945,
			"isDeleted": false,
			"id": "O03O86vz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -280.5174964904786,
			"y": -172.08070161049437,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 50,
			"seed": 1806505031,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654884234,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sophos XG\nFirewall",
			"rawText": "Sophos XG\nFirewall",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "30k8vHR0qaCAN7itFEfmh",
			"originalText": "Sophos XG\nFirewall"
		},
		{
			"type": "arrow",
			"version": 493,
			"versionNonce": 1780213383,
			"isDeleted": false,
			"id": "9jHUT0Rt0VQplyRicavev",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -665.9488319396974,
			"y": -193.7679422110803,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 316.1058044433594,
			"height": 0,
			"seed": 1083340713,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "3TtpjyrQVmQkhn_rBffX_",
				"gap": 23.31597900390625,
				"focus": -0.6235980739841214
			},
			"endBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 27.825531005859375,
				"focus": 0.5947419184788018
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					316.1058044433594,
					0
				]
			]
		},
		{
			"type": "text",
			"version": 373,
			"versionNonce": 243475817,
			"isDeleted": false,
			"id": "vgVUWYei",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -654.1378740722034,
			"y": -58.62431547181035,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 168,
			"height": 50,
			"seed": 565244775,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672654855596,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS Request to:\n* (websites)",
			"rawText": "DNS Request to:\n* (websites)",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DNS Request to:\n* (websites)"
		},
		{
			"type": "arrow",
			"version": 560,
			"versionNonce": 118193575,
			"isDeleted": false,
			"id": "V0RAsl1KorW0Mt2wD8KqL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -665.2747393065783,
			"y": -114.7700124932947,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 316.1058044433594,
			"height": 0,
			"seed": 1150786185,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "3TtpjyrQVmQkhn_rBffX_",
				"gap": 23.990071637025267,
				"focus": 0.40234906520789954
			},
			"endBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 27.15143837274036,
				"focus": -0.4116011352509512
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					316.1058044433594,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 864,
			"versionNonce": 205205703,
			"isDeleted": false,
			"id": "Xp-J3SmXVq-zbqzMIKE8f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -352.68216018676753,
			"y": -167.8273791701202,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 312.5669921875001,
			"height": 0,
			"seed": 640413319,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 30.664663696288926,
				"focus": 0.26428888610988316
			},
			"endBinding": {
				"elementId": "3TtpjyrQVmQkhn_rBffX_",
				"gap": 24.015658569335983,
				"focus": -0.2867076448807432
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-312.5669921875001,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 133,
			"versionNonce": 860323815,
			"isDeleted": false,
			"id": "WCzEoPIjXOvYruQjC6y4w",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -344.64885940551767,
			"y": -83.39177466305802,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 322.791162109375,
			"height": 0,
			"seed": 364208489,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672654916189,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"gap": 22.631362915039062,
				"focus": -0.8113239101584251
			},
			"endBinding": {
				"elementId": "3TtpjyrQVmQkhn_rBffX_",
				"gap": 21.824789428710915,
				"focus": 0.8098586474187656
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-322.791162109375,
					0
				]
			]
		},
		{
			"id": "kDzzTkz5wGQZ9uJdTD9fG",
			"type": "arrow",
			"x": -123.04523811340334,
			"y": -154.19721544565596,
			"width": 254.42595451108866,
			"height": 0,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1635130151,
			"version": 61,
			"versionNonce": 867129351,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1672654933017,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					254.42595451108866,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"focus": -0.09065622719951064,
				"gap": 11.972258377075264
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "TNdZarb9TRJmRWdG-UZ8r",
			"type": "arrow",
			"x": 116.6569890791369,
			"y": -125.92766056914382,
			"width": 235.57963709677415,
			"height": 0,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 597118953,
			"version": 38,
			"versionNonce": 1460351847,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1672654936638,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-235.57963709677415,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": {
				"elementId": "30k8vHR0qaCAN7itFEfmh",
				"focus": 0.2694654909726185,
				"gap": 16.094848472841363
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#862e9c",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 858.6885289715183,
		"scrollY": 465.8616392344034,
		"zoom": {
			"value": 1.55
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%