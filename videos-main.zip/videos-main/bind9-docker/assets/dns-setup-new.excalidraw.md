---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
PC ^ZiJ0Yf78

clcreative.de ^VCU9Ja4u

1. DNS Request to:
server1.home.clcreative.de ^3xCNQvCY

DNS Server
authorative for:
home.clcreative.de ^P5BNpv2B

server1.home.clcreative.de -> 10.20.0.2
server2.home.clcreative.de -> 10.20.0.3
*.kube1.home.clcreative.de -> 10.20.0.4
*.kube2.home.clcreative.de -> 10.20.0.5
mx home.clcreative.de -> 10.20.0.7
... ^JTOTF6Vy

2. DNS Answer:
server1.home.clcreative.de is at
10.20.0.2 ^P0BIlZKk

*public domain on cloudflare ^6NmfeEkR

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 234,
			"versionNonce": 147607334,
			"isDeleted": false,
			"id": "lP7pQ-Z0glRY5GMEIjyXS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -559.3739929199219,
			"y": -115.4496955871582,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 184,
			"height": 154,
			"seed": 1062597094,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "ZiJ0Yf78"
				}
			],
			"updated": 1672246155695,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 177,
			"versionNonce": 1140235110,
			"isDeleted": false,
			"id": "ZiJ0Yf78",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -480.8739929199219,
			"y": -50.9496955871582,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27,
			"height": 25,
			"seed": 2124875642,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246307087,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "PC",
			"rawText": "PC",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "lP7pQ-Z0glRY5GMEIjyXS",
			"originalText": "PC"
		},
		{
			"type": "rectangle",
			"version": 163,
			"versionNonce": 100891238,
			"isDeleted": false,
			"id": "y33XcjLwDazNvTDfFDCOu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -215.44937133789062,
			"y": -287.8097665206246,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 294,
			"height": 48,
			"seed": 1758119206,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "VCU9Ja4u"
				}
			],
			"updated": 1672246155695,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 177,
			"versionNonce": 283096570,
			"isDeleted": false,
			"id": "VCU9Ja4u",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -130.44937133789062,
			"y": -276.3097665206246,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 124,
			"height": 25,
			"seed": 1913391162,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246307088,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clcreative.de",
			"rawText": "clcreative.de",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "y33XcjLwDazNvTDfFDCOu",
			"originalText": "clcreative.de"
		},
		{
			"type": "text",
			"version": 170,
			"versionNonce": 28523942,
			"isDeleted": false,
			"id": "3xCNQvCY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -323.5968322753906,
			"y": -151.5169792175293,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 246,
			"height": 50,
			"seed": 1519579386,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1. DNS Request to:\nserver1.home.clcreative.de",
			"rawText": "1. DNS Request to:\nserver1.home.clcreative.de",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1. DNS Request to:\nserver1.home.clcreative.de"
		},
		{
			"type": "rectangle",
			"version": 222,
			"versionNonce": 342185914,
			"isDeleted": false,
			"id": "-zcP-NZSeQo1FqlKxtc-L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 160.91677856445312,
			"y": -119.19234848022461,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 267,
			"height": 157,
			"seed": 17576870,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "P5BNpv2B"
				}
			],
			"updated": 1672246155695,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 324,
			"versionNonce": 916078246,
			"isDeleted": false,
			"id": "P5BNpv2B",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 207.41677856445312,
			"y": -78.19234848022461,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 75,
			"seed": 197050810,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246307088,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS Server\nauthorative for:\nhome.clcreative.de",
			"rawText": "DNS Server\nauthorative for:\nhome.clcreative.de",
			"baseline": 67,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "-zcP-NZSeQo1FqlKxtc-L",
			"originalText": "DNS Server\nauthorative for:\nhome.clcreative.de"
		},
		{
			"type": "arrow",
			"version": 267,
			"versionNonce": 337006714,
			"isDeleted": false,
			"id": "_6bB5CJV98YX2rxafa59O",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.5511779785156,
			"y": -82.26752853393555,
			"strokeColor": "#364fc7",
			"backgroundColor": "transparent",
			"width": 441.8294677734375,
			"height": 1.3543724010337996,
			"seed": 634572518,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					441.8294677734375,
					1.3543724010337996
				]
			]
		},
		{
			"type": "text",
			"version": 419,
			"versionNonce": 462457894,
			"isDeleted": false,
			"id": "JTOTF6Vy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 206.78121948242188,
			"y": 57.64954193778658,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 382,
			"height": 151,
			"seed": 1890744954,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "server1.home.clcreative.de -> 10.20.0.2\nserver2.home.clcreative.de -> 10.20.0.3\n*.kube1.home.clcreative.de -> 10.20.0.4\n*.kube2.home.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n...",
			"rawText": "server1.home.clcreative.de -> 10.20.0.2\nserver2.home.clcreative.de -> 10.20.0.3\n*.kube1.home.clcreative.de -> 10.20.0.4\n*.kube2.home.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n...",
			"baseline": 143,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "server1.home.clcreative.de -> 10.20.0.2\nserver2.home.clcreative.de -> 10.20.0.3\n*.kube1.home.clcreative.de -> 10.20.0.4\n*.kube2.home.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n..."
		},
		{
			"type": "arrow",
			"version": 101,
			"versionNonce": 212480314,
			"isDeleted": false,
			"id": "Ij3KzY4e8YC-bkWsF8Erl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 114.58126831054688,
			"y": 11.758167266845703,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 450.04534912109375,
			"height": 0.912872314453125,
			"seed": 94634534,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-450.04534912109375,
					-0.912872314453125
				]
			]
		},
		{
			"type": "text",
			"version": 119,
			"versionNonce": 255334246,
			"isDeleted": false,
			"id": "P0BIlZKk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -272.4759826660156,
			"y": 28.318531036376953,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 304,
			"height": 75,
			"seed": 405871418,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2. DNS Answer:\nserver1.home.clcreative.de is at\n10.20.0.2",
			"rawText": "2. DNS Answer:\nserver1.home.clcreative.de is at\n10.20.0.2",
			"baseline": 68,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2. DNS Answer:\nserver1.home.clcreative.de is at\n10.20.0.2"
		},
		{
			"type": "text",
			"version": 337,
			"versionNonce": 830732794,
			"isDeleted": false,
			"id": "6NmfeEkR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -34.91585640285314,
			"y": -233.98849188763162,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 272,
			"height": 25,
			"seed": 1350079354,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1672246155695,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "*public domain on cloudflare",
			"rawText": "*public domain on cloudflare",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "*public domain on cloudflare"
		},
		{
			"id": "8U7ZianQ95dFgRSA5pjq4",
			"type": "line",
			"x": -555.5801948879075,
			"y": 293.32137033213735,
			"width": 1113.7024456521738,
			"height": 0,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1889698342,
			"version": 45,
			"versionNonce": 814072998,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1113.7024456521738,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "EizO3UG0",
			"type": "text",
			"x": -149.94802989130437,
			"y": 307.34165523363197,
			"width": 258,
			"height": 41,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 2061335098,
			"version": 134,
			"versionNonce": 1461895354,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"text": "split-horizon dns",
			"rawText": "split-horizon dns",
			"fontSize": 32.700789741847906,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 29,
			"containerId": null,
			"originalText": "split-horizon dns"
		},
		{
			"id": "wk-Hr1KAZfrRk2pZzQQKx",
			"type": "freedraw",
			"x": 220.75695270040762,
			"y": 463.84064682670254,
			"width": 202.41922129755437,
			"height": 93.668504797894,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 673267750,
			"version": 170,
			"versionNonce": 837959654,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.793775475543498,
					0
				],
				[
					-1.587550951086996,
					-0.7938020125679373
				],
				[
					-2.381432574728251,
					-1.5875774881113784
				],
				[
					-2.381432574728251,
					-2.3813795006793157
				],
				[
					-2.381432574728251,
					-4.7627855383831275
				],
				[
					-3.175208050271749,
					-7.144191576086939
				],
				[
					-3.175208050271749,
					-10.319399626358688
				],
				[
					-3.175208050271749,
					-12.7008056640625
				],
				[
					-3.175208050271749,
					-15.876013714334192
				],
				[
					-2.381432574728251,
					-18.257419752038004
				],
				[
					-0.793775475543498,
					-20.638799252717376
				],
				[
					0,
					-23.02020529042119
				],
				[
					0.793775475543498,
					-24.607809315557063
				],
				[
					1.587657099184753,
					-25.401611328124943
				],
				[
					2.381432574728251,
					-26.19541334069288
				],
				[
					4.762759001358631,
					-27.783017365828755
				],
				[
					7.93796705163038,
					-30.164423403532567
				],
				[
					11.11317510190213,
					-31.75202742866844
				],
				[
					12.700832201086882,
					-33.339631453804316
				],
				[
					14.288383152173878,
					-33.339631453804316
				],
				[
					16.66981572690213,
					-34.13343346637225
				],
				[
					18.257472826086882,
					-34.13343346637225
				],
				[
					20.638799252717376,
					-34.13343346637225
				],
				[
					21.432574728260875,
					-34.13343346637225
				],
				[
					22.22645635190213,
					-34.13343346637225
				],
				[
					23.020231827445627,
					-34.13343346637225
				],
				[
					25.40166440217388,
					-34.13343346637225
				],
				[
					28.576872452445627,
					-32.54582944123638
				],
				[
					30.95819887907612,
					-30.958225416100504
				],
				[
					31.752080502717376,
					-30.164423403532567
				],
				[
					32.545855978260875,
					-29.37062139096463
				],
				[
					33.33963145380437,
					-28.576819378396692
				],
				[
					34.13340692934776,
					-27.783017365828755
				],
				[
					34.13340692934776,
					-26.989215353260818
				],
				[
					33.33963145380437,
					-26.989215353260818
				],
				[
					32.545855978260875,
					-28.576819378396692
				],
				[
					31.752080502717376,
					-30.164423403532567
				],
				[
					30.95819887907612,
					-34.13343346637225
				],
				[
					30.95819887907612,
					-38.89621900475538
				],
				[
					30.95819887907612,
					-42.86522906759507
				],
				[
					30.95819887907612,
					-46.83423913043475
				],
				[
					32.545855978260875,
					-52.39082668138582
				],
				[
					34.927288552989125,
					-55.56603473165757
				],
				[
					38.89627207880437,
					-59.53504479449725
				],
				[
					41.27759850543475,
					-63.50405485733694
				],
				[
					44.4528065557065,
					-65.8854608950407
				],
				[
					44.4528065557065,
					-67.47306492017657
				],
				[
					45.24668817934776,
					-67.47306492017657
				],
				[
					48.421896229619506,
					-69.060642408288
				],
				[
					53.18465523097825,
					-72.23585045855975
				],
				[
					58.74129585597825,
					-75.41105850883145
				],
				[
					67.47303838315213,
					-78.5862665591032
				],
				[
					74.61722995923913,
					-81.76147460937494
				],
				[
					81.76152768342388,
					-82.55527662194294
				],
				[
					84.93673573369563,
					-83.34907863451082
				],
				[
					85.73051120923913,
					-83.34907863451082
				],
				[
					86.52428668478262,
					-83.34907863451082
				],
				[
					90.49327021059776,
					-82.55527662194294
				],
				[
					93.6684782608695,
					-78.5862665591032
				],
				[
					96.84368631114125,
					-76.20486052139944
				],
				[
					98.43134341032601,
					-73.82345448369563
				],
				[
					100.018894361413,
					-73.02965247112769
				],
				[
					100.018894361413,
					-71.44204844599182
				],
				[
					102.40032693614125,
					-69.85444442085594
				],
				[
					103.19410241168475,
					-66.67926290760869
				],
				[
					104.78165336277175,
					-64.29785686990482
				],
				[
					104.78165336277175,
					-61.12264881963313
				],
				[
					104.78165336277175,
					-57.15363875679344
				],
				[
					104.78165336277175,
					-54.77223271908963
				],
				[
					104.78165336277175,
					-52.39082668138582
				],
				[
					104.78165336277175,
					-50.80324919327444
				],
				[
					104.78165336277175,
					-51.59705120584238
				],
				[
					104.78165336277175,
					-53.97843070652169
				],
				[
					104.78165336277175,
					-57.94744076936138
				],
				[
					104.78165336277175,
					-64.29785686990482
				],
				[
					107.9568614130435,
					-69.060642408288
				],
				[
					109.54451851222825,
					-72.23585045855975
				],
				[
					111.13206946331513,
					-73.82345448369563
				],
				[
					111.9259510869565,
					-73.82345448369563
				],
				[
					113.5135020380435,
					-74.61725649626356
				],
				[
					113.5135020380435,
					-75.41105850883145
				],
				[
					115.89493461277175,
					-75.41105850883145
				],
				[
					118.2763671875,
					-75.41105850883145
				],
				[
					123.03912618885863,
					-76.20486052139944
				],
				[
					127.80188519021738,
					-77.79246454653531
				],
				[
					133.35852581521738,
					-78.5862665591032
				],
				[
					137.32750934103262,
					-80.17387058423907
				],
				[
					141.29649286684776,
					-80.96767259680706
				],
				[
					142.88414996603262,
					-80.96767259680706
				],
				[
					146.05935801630426,
					-79.38006857167119
				],
				[
					149.234566066576,
					-76.99866253396732
				],
				[
					151.61599864130426,
					-74.61725649626356
				],
				[
					154.79110054347825,
					-73.02965247112769
				],
				[
					157.1725331182065,
					-71.44204844599182
				],
				[
					159.55396569293475,
					-69.85444442085594
				],
				[
					161.935398267663,
					-66.67926290760869
				],
				[
					163.52294921875,
					-64.29785686990482
				],
				[
					164.31672469429338,
					-61.12264881963313
				],
				[
					165.11060631793475,
					-59.53504479449725
				],
				[
					165.11060631793475,
					-55.56603473165757
				],
				[
					165.11060631793475,
					-51.59705120584238
				],
				[
					164.31672469429338,
					-47.62804114300269
				],
				[
					163.52294921875,
					-44.45283309273094
				],
				[
					162.7291737432065,
					-43.659031080163004
				],
				[
					178.60521399456513,
					-43.659031080163004
				],
				[
					180.19276494565213,
					-43.659031080163004
				],
				[
					182.57419752038038,
					-43.659031080163004
				],
				[
					184.16174847146738,
					-43.659031080163004
				],
				[
					187.33695652173913,
					-42.86522906759507
				],
				[
					188.1307319972825,
					-42.86522906759507
				],
				[
					188.92461362092388,
					-42.07142705502713
				],
				[
					191.30594004755426,
					-41.27762504245919
				],
				[
					192.09982167119563,
					-38.89621900475538
				],
				[
					194.48114809782612,
					-35.72101095448369
				],
				[
					196.06880519701087,
					-33.339631453804316
				],
				[
					196.86258067255437,
					-30.958225416100504
				],
				[
					196.86258067255437,
					-27.783017365828755
				],
				[
					197.65635614809787,
					-24.607809315557063
				],
				[
					197.65635614809787,
					-21.432601265285314
				],
				[
					197.65635614809787,
					-18.257419752038004
				],
				[
					198.45023777173913,
					-15.082211701766255
				],
				[
					198.45023777173913,
					-13.49460767663038
				],
				[
					199.24401324728262,
					-10.319399626358688
				],
				[
					199.24401324728262,
					-7.144191576086939
				],
				[
					199.24401324728262,
					-4.7627855383831275
				],
				[
					199.24401324728262,
					-2.3813795006793157
				],
				[
					199.24401324728262,
					0
				],
				[
					198.45023777173913,
					2.3814060377038118
				],
				[
					197.65635614809787,
					3.9690100628396863
				],
				[
					197.65635614809787,
					5.556614087975561
				],
				[
					196.06880519701087,
					6.350416100543498
				],
				[
					194.48114809782612,
					7.9380201256793725
				],
				[
					192.89359714673913,
					7.9380201256793725
				],
				[
					190.51216457201087,
					8.73182213824731
				],
				[
					184.95563009510863,
					9.525624150815247
				],
				[
					177.01755689538038,
					10.319426163383184
				],
				[
					167.49193274456513,
					10.319426163383184
				],
				[
					157.96630859375,
					10.319426163383184
				],
				[
					149.234566066576,
					10.319426163383184
				],
				[
					143.677925441576,
					10.319426163383184
				],
				[
					137.32750934103262,
					10.319426163383184
				],
				[
					128.59576681385863,
					10.319426163383184
				],
				[
					118.2763671875,
					10.319426163383184
				],
				[
					108.75074303668475,
					9.525624150815247
				],
				[
					99.2251188858695,
					9.525624150815247
				],
				[
					89.69949473505437,
					9.525624150815247
				],
				[
					81.76152768342388,
					8.73182213824731
				],
				[
					72.23590353260863,
					7.144218113111435
				],
				[
					64.29783033288038,
					6.350416100543498
				],
				[
					56.35986328125,
					6.350416100543498
				],
				[
					49.215671705163004,
					6.350416100543498
				],
				[
					42.07148012907612,
					6.350416100543498
				],
				[
					34.927288552989125,
					6.350416100543498
				],
				[
					30.164423403532624,
					6.350416100543498
				],
				[
					25.40166440217388,
					6.350416100543498
				],
				[
					19.84502377717388,
					4.7628120754076235
				],
				[
					15.082264775815247,
					4.7628120754076235
				],
				[
					11.11317510190213,
					4.7628120754076235
				],
				[
					9.525624150815247,
					4.7628120754076235
				],
				[
					9.525624150815247,
					3.9690100628396863
				],
				[
					8.731848675271749,
					3.9690100628396863
				],
				[
					7.93796705163038,
					3.9690100628396863
				],
				[
					7.93796705163038,
					3.9690100628396863
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				7.93796705163038,
				3.9690100628396863
			]
		},
		{
			"id": "YNHaTEh-1EOdxcdrndMFt",
			"type": "freedraw",
			"x": -384.11922554347814,
			"y": 469.3972609146781,
			"width": 75.4110585088315,
			"height": 75.411085045856,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1555584230,
			"version": 71,
			"versionNonce": 1295948154,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.7938020125679373
				],
				[
					0,
					-1.5876040251358745
				],
				[
					0.7937754755434412,
					-7.9379935886548765
				],
				[
					1.5876040251358745,
					-15.876013714334249
				],
				[
					2.3813795006793157,
					-24.607809315557063
				],
				[
					2.3813795006793157,
					-31.75202742866844
				],
				[
					2.3813795006793157,
					-38.89624554177988
				],
				[
					2.3813795006793157,
					-46.040437117866816
				],
				[
					2.3813795006793157,
					-51.59705120584238
				],
				[
					2.3813795006793157,
					-54.772259256114125
				],
				[
					1.5876040251358745,
					-57.15366529381794
				],
				[
					1.5876040251358745,
					-58.741242781929316
				],
				[
					1.5876040251358745,
					-59.53504479449725
				],
				[
					0.7937754755434412,
					-61.12264881963313
				],
				[
					0.7937754755434412,
					-61.916450832201065
				],
				[
					0.7937754755434412,
					-62.710252844769
				],
				[
					0.7937754755434412,
					-65.09165888247281
				],
				[
					0.7937754755434412,
					-66.67926290760869
				],
				[
					0.7937754755434412,
					-67.47306492017663
				],
				[
					0.7937754755434412,
					-69.0606689453125
				],
				[
					1.5876040251358745,
					-69.0606689453125
				],
				[
					3.96898352581519,
					-69.0606689453125
				],
				[
					7.938020125679316,
					-69.0606689453125
				],
				[
					16.66981572690213,
					-69.0606689453125
				],
				[
					27.78304390285325,
					-67.47306492017663
				],
				[
					39.690047554347814,
					-66.67926290760869
				],
				[
					49.21561863111407,
					-65.88546089504075
				],
				[
					56.35986328124994,
					-65.88546089504075
				],
				[
					61.916450832201065,
					-65.09165888247281
				],
				[
					65.09165888247281,
					-64.29785686990488
				],
				[
					65.88543435801625,
					-64.29785686990488
				],
				[
					66.67926290760863,
					-64.29785686990488
				],
				[
					66.67926290760863,
					-63.50405485733694
				],
				[
					66.67926290760863,
					-62.710252844769
				],
				[
					67.47303838315213,
					-62.710252844769
				],
				[
					67.47303838315213,
					-59.53504479449725
				],
				[
					67.47303838315213,
					-53.18465523097825
				],
				[
					67.47303838315213,
					-43.659031080163004
				],
				[
					68.2668669327445,
					-30.958225416100504
				],
				[
					69.060642408288,
					-22.22642981487769
				],
				[
					69.060642408288,
					-11.113201638926625
				],
				[
					69.060642408288,
					-5.556614087975561
				],
				[
					69.85447095788038,
					0
				],
				[
					70.64824643342388,
					2.3814060377038118
				],
				[
					70.64824643342388,
					3.9690100628396863
				],
				[
					70.64824643342388,
					4.7628120754076235
				],
				[
					69.060642408288,
					5.556614087975561
				],
				[
					66.67926290760863,
					5.556614087975561
				],
				[
					61.916450832201065,
					6.350416100543498
				],
				[
					55.56603473165757,
					6.350416100543498
				],
				[
					46.83423913043475,
					6.350416100543498
				],
				[
					37.308614979619506,
					4.7628120754076235
				],
				[
					30.958251953124943,
					3.9690100628396863
				],
				[
					24.607835852581502,
					3.9690100628396863
				],
				[
					18.257419752038004,
					3.9690100628396863
				],
				[
					13.49460767663038,
					3.9690100628396863
				],
				[
					11.907003651494506,
					3.9690100628396863
				],
				[
					10.319399626358631,
					3.9690100628396863
				],
				[
					7.144191576086939,
					3.9690100628396863
				],
				[
					5.556587550951065,
					3.9690100628396863
				],
				[
					2.3813795006793157,
					3.175208050271749
				],
				[
					-1.5876040251358745,
					2.3814060377038118
				],
				[
					-3.175208050271749,
					1.5876040251358745
				],
				[
					-4.7628120754076235,
					1.5876040251358745
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				-4.7628120754076235,
				1.5876040251358745
			]
		},
		{
			"id": "8cG0yYUnfNDIXL8Srjspf",
			"type": "freedraw",
			"x": -379.35641346807057,
			"y": 400.3365919693656,
			"width": 65.09165888247281,
			"height": 36.514839504076065,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1476310950,
			"version": 38,
			"versionNonce": 514675494,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.7938020125678804
				],
				[
					1.5876040251358745,
					-1.5876040251358745
				],
				[
					3.175208050271749,
					-3.9690100628396294
				],
				[
					4.7628120754076235,
					-6.350389563519002
				],
				[
					7.938020125679316,
					-8.731795601222814
				],
				[
					11.113175101902186,
					-12.7008056640625
				],
				[
					15.082211701766312,
					-15.876013714334249
				],
				[
					19.05119522758156,
					-20.638825789741816
				],
				[
					22.226403277853308,
					-23.814007302989125
				],
				[
					24.60783585258156,
					-26.19541334069288
				],
				[
					26.195439877717376,
					-27.783017365828755
				],
				[
					27.782990828804373,
					-29.37062139096463
				],
				[
					28.57681937839675,
					-29.37062139096463
				],
				[
					29.370594853940247,
					-29.37062139096463
				],
				[
					30.95819887907612,
					-30.164423403532624
				],
				[
					32.54580290421194,
					-31.75202742866844
				],
				[
					34.133406929347814,
					-33.339631453804316
				],
				[
					34.92723547894025,
					-34.13343346637225
				],
				[
					35.72101095448369,
					-34.13343346637225
				],
				[
					36.514839504076065,
					-34.13343346637225
				],
				[
					37.30861497961956,
					-33.339631453804316
				],
				[
					37.30861497961956,
					-32.54582944123638
				],
				[
					40.48382302989131,
					-29.37062139096463
				],
				[
					44.4528065557065,
					-24.607809315557006
				],
				[
					48.42184315557063,
					-19.84502377717388
				],
				[
					51.59705120584238,
					-15.876013714334249
				],
				[
					53.97843070652175,
					-13.49460767663038
				],
				[
					56.35986328125,
					-11.113201638926625
				],
				[
					59.53507133152175,
					-8.731795601222814
				],
				[
					61.916450832201065,
					-6.350389563519002
				],
				[
					64.29783033288044,
					-3.9690100628396294
				],
				[
					64.29783033288044,
					-2.381406037703755
				],
				[
					65.09165888247281,
					-2.381406037703755
				],
				[
					65.09165888247281,
					2.3814060377038118
				],
				[
					65.09165888247281,
					2.3814060377038118
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				65.09165888247281,
				2.3814060377038118
			]
		},
		{
			"id": "ZloExgKlCKV6jImY5vW_t",
			"type": "freedraw",
			"x": -372.21222189198363,
			"y": 370.96597057840097,
			"width": 3.175208050271749,
			"height": 17.463617739470124,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 463938362,
			"version": 10,
			"versionNonce": 1809930810,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.7938020125678804
				],
				[
					0.7938285495923765,
					3.9690100628396294
				],
				[
					1.5876040251358745,
					9.525597613790751
				],
				[
					1.5876040251358745,
					13.49460767663038
				],
				[
					2.3813795006793725,
					16.66981572690213
				],
				[
					3.175208050271749,
					17.463617739470124
				],
				[
					3.175208050271749,
					17.463617739470124
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				3.175208050271749,
				17.463617739470124
			]
		},
		{
			"id": "SRn7RifcKf8LFswVZF9LL",
			"type": "freedraw",
			"x": -369.0370138417119,
			"y": 373.3473766161047,
			"width": 7.144191576086996,
			"height": 9.525597613790751,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1437753958,
			"version": 16,
			"versionNonce": 1092877926,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.793775475543498,
					0
				],
				[
					3.175208050271749,
					0
				],
				[
					4.7628120754076235,
					0
				],
				[
					6.350416100543498,
					0
				],
				[
					7.144191576086996,
					0
				],
				[
					6.350416100543498,
					0
				],
				[
					6.350416100543498,
					0.7938020125679941
				],
				[
					6.350416100543498,
					3.175208050271749
				],
				[
					6.350416100543498,
					5.556587550951122
				],
				[
					6.350416100543498,
					7.144191576086996
				],
				[
					7.144191576086996,
					8.73179560122287
				],
				[
					7.144191576086996,
					9.525597613790751
				],
				[
					7.144191576086996,
					9.525597613790751
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				7.144191576086996,
				9.525597613790751
			]
		},
		{
			"id": "Grr9kAmbdxaQZywwBS2CM",
			"type": "freedraw",
			"x": -365.06803031589664,
			"y": 466.22205286440635,
			"width": 13.494607676630437,
			"height": 38.10244352921194,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1166105658,
			"version": 29,
			"versionNonce": 1374552826,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.7938020125679373
				],
				[
					0,
					-1.5876040251358745
				],
				[
					0,
					-7.144191576086939
				],
				[
					0,
					-11.907003651494563
				],
				[
					0,
					-17.463617739470067
				],
				[
					0,
					-24.607809315557063
				],
				[
					0.7938285495923765,
					-29.37062139096463
				],
				[
					0.7938285495923765,
					-31.75202742866844
				],
				[
					0.7938285495923765,
					-32.54582944123638
				],
				[
					0.7938285495923765,
					-33.339631453804316
				],
				[
					1.5876040251358745,
					-33.339631453804316
				],
				[
					3.9690365998641255,
					-33.339631453804316
				],
				[
					7.9380201256793725,
					-33.339631453804316
				],
				[
					10.319452700407624,
					-32.54582944123638
				],
				[
					11.113228175951065,
					-32.54582944123638
				],
				[
					11.113228175951065,
					-31.75202742866844
				],
				[
					11.907056725543441,
					-30.164423403532567
				],
				[
					12.70083220108694,
					-26.195413340692937
				],
				[
					13.494607676630437,
					-20.638825789741816
				],
				[
					13.494607676630437,
					-13.494607676630437
				],
				[
					13.494607676630437,
					-7.144191576086939
				],
				[
					13.494607676630437,
					-3.175208050271749
				],
				[
					13.494607676630437,
					1.5876040251358745
				],
				[
					13.494607676630437,
					3.175208050271749
				],
				[
					13.494607676630437,
					4.7628120754076235
				],
				[
					13.494607676630437,
					4.7628120754076235
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				13.494607676630437,
				4.7628120754076235
			]
		},
		{
			"id": "Y1QJ5Leq",
			"type": "text",
			"x": 200.11815344769025,
			"y": 507.23150004511285,
			"width": 210,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 71405242,
			"version": 25,
			"versionNonce": 237191590,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"text": "cloudflare dns server",
			"rawText": "cloudflare dns server",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "cloudflare dns server"
		},
		{
			"type": "text",
			"version": 96,
			"versionNonce": 1239913402,
			"isDeleted": true,
			"id": "jBs41WTM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -424.26486073369557,
			"y": 504.6477438885231,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 157,
			"height": 25,
			"seed": 1305575546,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "home dns server",
			"rawText": "home dns server",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "home dns server"
		},
		{
			"type": "rectangle",
			"version": 212,
			"versionNonce": 1490558182,
			"isDeleted": true,
			"id": "CXQzqIzVohh2QLzeFywNH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.87364130434787,
			"y": 411.2416424958602,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 294,
			"height": 48,
			"seed": 1121151930,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "K9hGSEvh"
				}
			],
			"updated": 1672246303444,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 225,
			"versionNonce": 1177216698,
			"isDeleted": true,
			"id": "K9hGSEvh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -107.87364130434787,
			"y": 422.7416424958602,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 124,
			"height": 25,
			"seed": 389399782,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1672246307089,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clcreative.de",
			"rawText": "clcreative.de",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "CXQzqIzVohh2QLzeFywNH",
			"originalText": "clcreative.de"
		},
		{
			"type": "text",
			"version": 552,
			"versionNonce": 114266150,
			"isDeleted": true,
			"id": "PJCrdk6Y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -515.1860988451086,
			"y": 585.8801604561181,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 333,
			"height": 151,
			"seed": 668901222,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "server1.clcreative.de -> 10.20.0.2\nserver2.clcreative.de -> 10.20.0.3\n*.kube1.clcreative.de -> 10.20.0.4\n*.kube2.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n...",
			"rawText": "server1.clcreative.de -> 10.20.0.2\nserver2.clcreative.de -> 10.20.0.3\n*.kube1.clcreative.de -> 10.20.0.4\n*.kube2.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n...",
			"baseline": 143,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "server1.clcreative.de -> 10.20.0.2\nserver2.clcreative.de -> 10.20.0.3\n*.kube1.clcreative.de -> 10.20.0.4\n*.kube2.clcreative.de -> 10.20.0.5\nmx home.clcreative.de -> 10.20.0.7\n..."
		},
		{
			"type": "text",
			"version": 650,
			"versionNonce": 1003318586,
			"isDeleted": true,
			"id": "U1EieDQS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 141.34292204483705,
			"y": 571.4007107278572,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 376,
			"height": 151,
			"seed": 1388402170,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1672246303444,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "server1.clcreative.de -> 147.257.10.23\nserver2.clcreative.de -> 147.257.11.12\n*.kube1.clcreative.de -> 147.257.64.57\n*.kube2.clcreative.de -> 142.257.75.46\nmx home.clcreative.de -> 143.257.152.3\n...",
			"rawText": "server1.clcreative.de -> 147.257.10.23\nserver2.clcreative.de -> 147.257.11.12\n*.kube1.clcreative.de -> 147.257.64.57\n*.kube2.clcreative.de -> 142.257.75.46\nmx home.clcreative.de -> 143.257.152.3\n...",
			"baseline": 143,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "server1.clcreative.de -> 147.257.10.23\nserver2.clcreative.de -> 147.257.11.12\n*.kube1.clcreative.de -> 147.257.64.57\n*.kube2.clcreative.de -> 142.257.75.46\nmx home.clcreative.de -> 143.257.152.3\n..."
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 609.8253226902173,
		"scrollY": -150.14051652991253,
		"zoom": {
			"value": 1.1500000000000001
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%